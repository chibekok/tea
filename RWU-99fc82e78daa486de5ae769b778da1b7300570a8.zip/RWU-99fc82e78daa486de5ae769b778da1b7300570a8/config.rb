preferred_syntax = :scss
http_path = '/build/'
css_dir = 'build/css'
sass_dir = 'src/scss'
images_dir = 'build/images'
javascripts_dir = 'build/javascripts'
output_style = :expanded