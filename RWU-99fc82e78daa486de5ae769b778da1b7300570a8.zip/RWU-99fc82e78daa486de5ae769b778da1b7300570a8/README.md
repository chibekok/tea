# Remote Workers United
Very simple node/react app making work more fun for remote workers. It takes a webcam picture every x seconds and sends it to everyone connected.
Created for remote working colleagues who became a bit lonely.
